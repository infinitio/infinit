/*
 
  Pastis - Peer-to-Peer File System
  Copyright (C) 2003 LIP6 - Laboratoire d'Informatique de Paris 6.
 
  This program is free software;  you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free  Software
  Foundation; either version 2 of the License, or any later version.
 
  This  program  is  distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or  FITNESS
  FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 
  You should have  received  a copy of the GNU General Public License along with
  this program; if not, write to the Free  Software Foundation, Inc., 59  Temple
  Place - Suite 330, Boston, MA  02111-1307, USA.
 
 */

package rice.pastry.socket;

import java.net.*;


/*
 * This class is a wrapper to support Modelnet emulation.
 *
 * @author Fabio Picconi
 * @version $Id: VirtualAddress.java,v 1.2 2005/08/16 14:18:20 picconi Exp $
 */
public class VirtualAddress {
    
    private static String virtualaddr = null;
    
    public static void set( String addr ) {
        virtualaddr = addr;
    }
    
    public static InetSocketAddress getISA() {
        return getISA( 0 );
    }
    
    public static InetSocketAddress getISA( int port ) {
        InetSocketAddress res = null;
        
        try {
            String addr = virtualaddr != null ? virtualaddr : InetAddress.getLocalHost().getHostAddress();
            res = new InetSocketAddress( InetAddress.getByName( addr ), port );
        } catch (UnknownHostException e) {
            System.out.println("PANIC: Unknown host in getAddress. " + e);
            System.exit(1);
        }
        
        return res;
    }
    
    public static InetAddress getAddress() {
        InetAddress res = null;
        
        try {
            res = virtualaddr != null ?
                InetAddress.getByName( virtualaddr ) :
                InetAddress.getLocalHost() ;
        } catch (UnknownHostException e) {
            System.out.println("PANIC: Unknown host in getAddress. " + e);
            System.exit(1);
        }
        return res;
    }
    
    public static InetSocketAddress destAddr( InetSocketAddress addr ) {
        String newaddr = addr.getAddress().getHostAddress();
        // DSM do not do ModelNet routing to our own address
        if(virtualaddr != null  && !virtualaddr.equals(newaddr) )
            newaddr = newaddr.replaceFirst( "10.0", "10.128" );
        return new InetSocketAddress( newaddr, addr.getPort() );
    }
    
    public static String get() {
        return virtualaddr;
    }
    
}
